var indexSectionsWithContent =
{
  0: "abcfgilmnoprstu~",
  1: "lmnp",
  2: "lmnpru",
  3: "abcfgilmnoprst~",
  4: "o",
  5: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de Dados",
  2: "Arquivos",
  3: "Funções",
  4: "Amigas",
  5: "Páginas"
};

