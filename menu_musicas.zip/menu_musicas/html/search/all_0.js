var searchData=
[
  ['addmusica_0',['addMusica',['../a00036.html#a1c2cf004e51f29ffcc0fc79fb650fab3',1,'Playlist::addMusica(const Musica &amp;musica)'],['../a00036.html#aa3c854d7b161faaa406b8c0a00676cfb',1,'Playlist::addMusica(const Playlist &amp;playlist)']]],
  ['adicionarelementos_1',['adicionarElementos',['../a00024.html#a146e31311259bbf781b8fce9c5cc6408',1,'Lista']]]
];
