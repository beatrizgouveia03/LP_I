var searchData=
[
  ['remmusica_103',['remMusica',['../a00036.html#a3880c88a9705ed92daa90c35e56b6fe4',1,'Playlist::remMusica(const Musica &amp;musica)'],['../a00036.html#a40a75b77288c717213fc8e5b3d952781',1,'Playlist::remMusica(const Playlist &amp;playlist)']]],
  ['remover_104',['remover',['../a00024.html#a820a6851e127aadde092e88be73672c2',1,'Lista']]],
  ['removerelementos_105',['removerElementos',['../a00024.html#aef99627ddaf3154d76700ee41774a21b',1,'Lista']]]
];
