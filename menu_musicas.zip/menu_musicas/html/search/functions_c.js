var searchData=
[
  ['setartista_106',['setArtista',['../a00028.html#a9fed71e8c706a5cff815a8060d5e11b6',1,'Musica']]],
  ['setcabeca_107',['setCabeca',['../a00024.html#aa09211c096accdf53703b208051611d0',1,'Lista']]],
  ['setcauda_108',['setCauda',['../a00024.html#a385c79cac116d9773cf7d0d5e9e00606',1,'Lista']]],
  ['setmusicas_109',['setMusicas',['../a00036.html#ab2d1ce4fd645fbc1040ba0f634554617',1,'Playlist']]],
  ['setnome_110',['setNome',['../a00036.html#a5bbe44510f50d7eaeb2ce7d557f4b79b',1,'Playlist']]],
  ['setproximo_111',['setProximo',['../a00032.html#a1a1896dd72a9d6e40f8cf6fc64256a81',1,'No']]],
  ['settitulo_112',['setTitulo',['../a00028.html#a148970ba1a87f290cd8a19f084925a00',1,'Musica']]],
  ['setvalor_113',['setValor',['../a00032.html#a3bb2f1c77fa3837cb2d9d930ae8508b7',1,'No']]]
];
