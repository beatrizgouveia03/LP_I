var searchData=
[
  ['getartista_77',['getArtista',['../a00028.html#afa031aa01fdb8995faa35ebedb0862a1',1,'Musica']]],
  ['getcabeca_78',['getCabeca',['../a00024.html#ab1d687706cd838d94ef05648b4526359',1,'Lista']]],
  ['getcauda_79',['getCauda',['../a00024.html#abbb4d1b6b8fdd9411805d16bb869f315',1,'Lista']]],
  ['getmusicas_80',['getMusicas',['../a00036.html#ae578afd0a026dae54f1ae1f881071dc1',1,'Playlist']]],
  ['getnome_81',['getNome',['../a00036.html#aca3a69d3fb7bb8de19718c655814e8c7',1,'Playlist']]],
  ['getproximo_82',['getProximo',['../a00032.html#ab93313a2d4988a5a087ae8166e3ea2fa',1,'No']]],
  ['gettitulo_83',['getTitulo',['../a00028.html#a1314371aa34b2e35f83d5b78780a308c',1,'Musica']]],
  ['getvalor_84',['getValor',['../a00032.html#a78682b8bf11f29339bfbaa4fb9d0f780',1,'No']]]
];
