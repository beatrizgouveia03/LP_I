var searchData=
[
  ['tamanho_53',['tamanho',['../a00024.html#ac31bb14de15503e1ab89b4bca1f60df0',1,'Lista']]],
  ['trataracao_54',['tratarAcao',['../a00014.html#a6d7db27eaff6800de14a789716de0cdb',1,'utilities.hpp']]]
];
