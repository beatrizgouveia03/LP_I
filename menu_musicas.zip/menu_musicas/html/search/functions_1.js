var searchData=
[
  ['buscar_72',['buscar',['../a00024.html#a497c9d055f303c4292c9e26aa5cf015b',1,'Lista']]],
  ['buscarporindice_73',['buscarPorIndice',['../a00024.html#a721cf84cd22fe2af057bd895cfd35616',1,'Lista']]]
];
