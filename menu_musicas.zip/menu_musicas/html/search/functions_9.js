var searchData=
[
  ['operator_2b_99',['operator+',['../a00024.html#a69e6bbe8f73a08f4b596cba38ecbca15',1,'Lista::operator+()'],['../a00036.html#a36debb8e24affc5f728e3f769551efdc',1,'Playlist::operator+(const Playlist &amp;playlist)'],['../a00036.html#aa3c1a3813a738f4f0ce64eb1b9358d34',1,'Playlist::operator+(const Musica &amp;musica)']]],
  ['operator_2d_100',['operator-',['../a00024.html#acbdcf456a0daa68c10a7754801b90a61',1,'Lista::operator-()'],['../a00036.html#a124e83f9bd9fc040e19fe4d092584467',1,'Playlist::operator-(const Playlist &amp;playlist)'],['../a00036.html#a4858c56cace2dd32bbba172b8494b775',1,'Playlist::operator-(const Musica &amp;musica)']]],
  ['operator_3d_3d_101',['operator==',['../a00028.html#a9e3929d795afba5fa339b08d8ed58761',1,'Musica::operator==()'],['../a00036.html#ab7873a446bec2231e7b63d5e4dcb71dc',1,'Playlist::operator==()']]]
];
