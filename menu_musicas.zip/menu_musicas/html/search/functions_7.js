var searchData=
[
  ['menuextras_89',['menuExtras',['../a00014.html#a962cffaf4d56843c6d5de420e1c7032a',1,'utilities.hpp']]],
  ['menulistagemmusicas_90',['menuListagemMusicas',['../a00014.html#ab4244b043bbf75fc020668af42ae4eeb',1,'utilities.hpp']]],
  ['menulistagemplaylists_91',['menuListagemPlaylists',['../a00014.html#a011f621a2845d786e59065a69d9b1079',1,'utilities.hpp']]],
  ['menumusicas_92',['menuMusicas',['../a00014.html#a8169d4bcc0e4bebb4b54a1f0f07f9d87',1,'utilities.hpp']]],
  ['menumusicasemplaylists_93',['menuMusicasEmPlaylists',['../a00014.html#aa880bffbfd870276ef0086ceb87b5693',1,'utilities.hpp']]],
  ['menuplaylists_94',['menuPlaylists',['../a00014.html#ab7b84b514d4c9c6749d5fadb8651e811',1,'utilities.hpp']]],
  ['menuprincipal_95',['menuPrincipal',['../a00014.html#a62b69aadfe7d5f496d2bab0370395666',1,'utilities.hpp']]],
  ['menutocarmusicas_96',['menuTocarMusicas',['../a00014.html#a4ee4fa3cb667ce10579ee63555e5a5b5',1,'utilities.hpp']]],
  ['musica_97',['Musica',['../a00028.html#a435c4de75bd638108bf9caae58000e18',1,'Musica::Musica()'],['../a00028.html#a69d50c28cdef2c3dce8a874daa7e81d9',1,'Musica::Musica(const string &amp;titulo, const string &amp;artista)']]]
];
