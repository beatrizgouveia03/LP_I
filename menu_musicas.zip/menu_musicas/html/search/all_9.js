var searchData=
[
  ['operator_2b_34',['operator+',['../a00024.html#a69e6bbe8f73a08f4b596cba38ecbca15',1,'Lista::operator+()'],['../a00036.html#a36debb8e24affc5f728e3f769551efdc',1,'Playlist::operator+(const Playlist &amp;playlist)'],['../a00036.html#aa3c1a3813a738f4f0ce64eb1b9358d34',1,'Playlist::operator+(const Musica &amp;musica)']]],
  ['operator_2d_35',['operator-',['../a00024.html#acbdcf456a0daa68c10a7754801b90a61',1,'Lista::operator-()'],['../a00036.html#a124e83f9bd9fc040e19fe4d092584467',1,'Playlist::operator-(const Playlist &amp;playlist)'],['../a00036.html#a4858c56cace2dd32bbba172b8494b775',1,'Playlist::operator-(const Musica &amp;musica)']]],
  ['operator_3c_3c_36',['operator&lt;&lt;',['../a00024.html#a0623e3a44d2d89ef1dfc900a6a24ac47',1,'Lista::operator&lt;&lt;()'],['../a00028.html#ac2452a38a9f009be8411506bdb2b487f',1,'Musica::operator&lt;&lt;()'],['../a00036.html#a63b1b4aba7f202b93d95ecd38706eba1',1,'Playlist::operator&lt;&lt;()'],['../a00036.html#a40ddbe801a28b1b9197076bd82616204',1,'Playlist::operator&lt;&lt;()']]],
  ['operator_3d_3d_37',['operator==',['../a00028.html#a9e3929d795afba5fa339b08d8ed58761',1,'Musica::operator==()'],['../a00036.html#ab7873a446bec2231e7b63d5e4dcb71dc',1,'Playlist::operator==()']]],
  ['operator_3e_3e_38',['operator&gt;&gt;',['../a00024.html#a1cbbc87a7c477b098463a398c277bb25',1,'Lista::operator&gt;&gt;()'],['../a00036.html#a2caa4589ba6ba8e65aad0e733d2bb8b9',1,'Playlist::operator&gt;&gt;()']]]
];
