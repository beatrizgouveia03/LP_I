var searchData=
[
  ['configuracaoinicialmusicas_4',['configuracaoInicialMusicas',['../a00014.html#ae4cd3f5b8933f51dc68c71786891be71',1,'utilities.hpp']]],
  ['configuracaoinicialplaylists_5',['configuracaoInicialPlaylists',['../a00014.html#ade45e1e639adaf2b66b29b05a7dbbb0a',1,'utilities.hpp']]]
];
